const Setting = {
    dev:{ 
        url : "http://10.175.173.6:8080/"
    },
    prod : {
        url: ""
    }
};


export default Setting; 