export const LOADER_ON = 'LOADER_ON';
export const LOADER_OFF = 'LOADER_OFF';